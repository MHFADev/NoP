import express from 'express';
import cors from 'cors';
import ytdl from 'ytdl-core';
import fetch from 'node-fetch';

const app = express();
const PORT = 5000;
const API_KEY = 'AIzaSyAqOFrbr09q_3CvEVGZi70YuZHz1mytUfw'; // API YouTube Data v3

app.use(cors());

// Search lagu
app.get('/search', async (req, res) => {
  const query = req.query.q;
  if (!query) return res.status(400).json({ error: 'Query kosong' });
  
  const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&maxResults=15&q=${encodeURIComponent(query)}&key=${API_KEY}`;
  try {
    const response = await fetch(url);
    const data = await response.json();
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: 'Gagal fetch data YouTube' });
  }
});

// Download MP3
app.get('/download', async (req, res) => {
  const videoId = req.query.id;
  if (!videoId) return res.status(400).json({ error: 'ID video kosong' });
  
  try {
    const info = await ytdl.getInfo(videoId);
    res.header('Content-Disposition', `attachment; filename="${info.videoDetails.title}.mp3"`);
    ytdl(videoId, { filter: 'audioonly' }).pipe(res);
  } catch (err) {
    res.status(500).json({ error: 'Gagal download' });
  }
});

app.listen(PORT, () => {
  console.log(`Backend berjalan di http://localhost:${PORT}`);
});