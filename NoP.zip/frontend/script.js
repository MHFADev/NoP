const searchInput = document.getElementById('search');
const resultsDiv = document.getElementById('results');
const player = document.getElementById('player');
const downloadBtn = document.getElementById('downloadBtn');

let playlist = [];
let currentIndex = 0;

searchInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') {
    searchSongs(searchInput.value);
  }
});

async function searchSongs(query) {
  resultsDiv.innerHTML = 'Loading...';
  const res = await fetch(`http://localhost:5000/search?q=${query}`);
  const data = await res.json();
  displayResults(data.items);
}

function displayResults(items) {
  resultsDiv.innerHTML = '';
  playlist = [];
  items.forEach(video => {
    const videoId = video.id.videoId;
    const title = video.snippet.title;
    const thumb = video.snippet.thumbnails.medium.url;
    playlist.push(videoId);
    
    const div = document.createElement('div');
    div.className = 'result-item';
    div.innerHTML = `
            <img src="${thumb}" alt="${title}">
            <p>${title}</p>
            <button onclick="playSong('${videoId}')">Play</button>
        `;
    resultsDiv.appendChild(div);
  });
}

function playSong(videoId) {
  currentIndex = playlist.indexOf(videoId);
  player.src = `https://www.youtube.com/watch?v=${videoId}`;
  player.play();
  downloadBtn.onclick = () => {
    window.location.href = `http://localhost:5000/download?id=${videoId}`;
  };
}